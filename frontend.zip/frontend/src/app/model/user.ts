export class User {
    username: string;
    email: string;
    password: number;

}