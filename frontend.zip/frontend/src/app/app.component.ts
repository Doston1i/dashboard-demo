import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'dashboard';
  currentUser: any = localStorage.getItem("authUser");
  constructor(private router: Router) { }

  ngOnInit(): void {
    if (this.currentUser) {
    }
  }

  onLogOut(): void {
    localStorage.clear();
    this.router.navigate(['/login']);
  }

}