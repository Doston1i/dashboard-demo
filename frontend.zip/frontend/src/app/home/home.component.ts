import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { StudentService } from '../services/student.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

 
constructor(private studentSvc: StudentService, private fb: FormBuilder){}
student = [];
submitted = false;
studentGreads: any = ['A', 'B', 'C', 'D']

studentGreadsForm = this.fb.group({
  name: ['', [Validators.required]]
})

ngOnInit(): void {
  this.studentSvc.getStudentRequest().subscribe((data: any[])=>{
    this.student = data;
  })
  
  // this.studentSvc.getStudentByGradeRequest('B').subscribe((data: any[])=>{
  //   console.log(data);
  //   this.student = data;
  // })
}

/* Select Dropdown error handling */
public handleError = (controlName: string, errorName: string) => {
  return this.studentGreadsForm.controls[controlName].hasError(errorName);
}

onSubmit() {
  this.submitted = true;
  this.studentSvc.getStudentByGradeRequest(this.studentGreadsForm.value.name).subscribe((data: any[])=>{
    console.log(data);
    this.student = data;
  })
}
}
