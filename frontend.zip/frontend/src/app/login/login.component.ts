import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  isAuth = false;
  userForm: any = {
    username: null,
    password: null
  };

  constructor(private authService: AuthService, private router: Router) { }

  user = '1';
  ngOnInit(): void {
    localStorage.setItem('SeesionUser',this.user)  

  }
  onSubmit(): void {
    const { username, password } = this.userForm;
    this.authService.login(username, password).subscribe(
      user => {
        if(user){
          localStorage.setItem('authUser', JSON.stringify(user));
          this.router.navigate(['/home']);
        }else{
          this.isAuth = true;
          this.router.navigate(['/login']);
        }
      },
      err => {
        err.error.message;
        this.router.navigate(['/login']);
      }
    );
  }

  reloadPage(): void {
    window.location.reload();
  }
}