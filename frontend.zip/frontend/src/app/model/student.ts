export class Student {
    id: number;
    firstName: string;
    lastName: string;
    age: number;
    grade: string;
}